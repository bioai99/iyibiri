# İyiBiri — Claude Code İçin İş Emri

> Bu dokümanı Claude Code'a aynen yapıştır. Altındaki design handoff klasörüyle birlikte çalışacak.

---

## Sen kimsin, ne yapıyorsun

Sen İyiBiri mobil uygulamasını **React Native + Expo + TypeScript** ile kuran bir senior frontend engineer'sın. Design handoff paketi (`design_handoff_iyibiri/`) elinde. Görevin, HTML + JSX prototipindeki ekranları production-ready RN kod tabanına port etmek.

Uygulama: **İyilik üzerine kurulu sosyal platform.** Kullanıcı görev seçiyor (kan bağışı, komşu yaşlıya yardım, park temizliği…), tamamlıyor, Karma token kazanıyor, rozet topluyor. Marka dili: _siyah arkaplan + mat altın vurgu, Fraunces italik display, sakin ve sevecen._

---

## 1. Handoff paketini oku (SIRAYLA)

Başlamadan önce bu dosyaları **oku ve anla**, özetleme yap:

1. `design_handoff_iyibiri/README.md` — Sistem özeti, dosya haritası, tasarım kararları.
2. `design_handoff_iyibiri/IMPLEMENTATION.md` — Adım adım port kılavuzu.
3. `design_handoff_iyibiri/screens_index.json` — Tüm ekranların meta listesi (route, component adı, state notları).
4. `design_handoff_iyibiri/examples/theme.ts` — Token sistemi (color, typography, spacing, radii, shadow).
5. `design_handoff_iyibiri/examples/Button.tsx` — Canonical component örneği.

Sonra `design_handoff_iyibiri/ds/` altındaki **tüm .jsx dosyalarını** aç — bunlar prototip componentlerinin kaynak kodu. RN'e port ederken buradan pixel/spacing/state değerlerini birebir alacaksın.

Tarayıcıda çalışan prototipi görmek için `design_handoff_iyibiri/App v2.html` dosyasını aç — tüm akışı tek sayfada sıralı şekilde görürsün.

---

## 2. Teknik stack (sabit)

```
React Native 0.74+
Expo SDK 51
TypeScript strict
Expo Router (file-based routing)
react-native-reanimated 3 (animasyonlar için)
expo-font (font yükleme)
@shopify/flash-list (uzun listeler için)
```

Form için `react-hook-form + zod`. State için basit React Context + hooks (Redux/Zustand yok — proje henüz o ölçekte değil).

---

## 3. Klasör yapısı

```
app/                          # Expo Router
  (auth)/
    landing.tsx
    register.tsx
    login.tsx
    otp.tsx
  (onboarding)/
    welcome.tsx
    values.tsx
    location.tsx
    notifications.tsx
  (tabs)/
    _layout.tsx              # Bottom nav
    index.tsx                # Home
    discover.tsx
    impact.tsx
    profile.tsx
  tasks/
    [id].tsx                 # Task detail
    flow/
      accept.tsx
      enroute.tsx
      verify.tsx
      complete.tsx
  _layout.tsx                # Root layout + ThemeProvider

src/
  theme/
    index.ts                 # examples/theme.ts'den port
    tokens.ts
  components/
    ui/                      # Button, Input, Badge, Tag, Card, ...
    KarmaToken.tsx           # SVG → react-native-svg ile port
    TaskCard.tsx
    SectionHeader.tsx
  hooks/
    useTheme.ts
  types/
    task.ts
    user.ts
  mocks/
    tasks.ts                 # Prototipteki sahte verilerle dolu
```

---

## 4. Port etme kuralları (ÖNEMLİ)

### 4.1 — Pixel-perfect olmak zorunda

Prototipteki tüm değerler (padding, font-size, border-radius, shadow offset…) **birebir** theme token'larına taşınır. Kendi değerlerini uydurma. Hex değerleri tahmin etme — `theme.ts`'den oku.

### 4.2 — HTML → RN çevirisi

| HTML/CSS | RN karşılığı |
|---|---|
| `<div>` | `<View>` |
| `<span>`, `<p>`, `<h*>` | `<Text>` (tüm metin Text içinde olmalı) |
| `onClick` | `onPress` |
| `style={{...}}` inline | `StyleSheet.create` (performans) |
| `flex: 1` | aynı |
| `flexDirection: row` | aynı (RN default `column`) |
| `gap` | RN 0.71+ destekliyor, kullan |
| `<svg>` | `react-native-svg` paketi |
| `<img>` | `<Image source={{uri}}/>` veya `expo-image` |
| `backdrop-filter: blur` | `expo-blur` `<BlurView>` |
| Gradient | `expo-linear-gradient` |

### 4.3 — Typography

`Fraunces` italik display için: `fontFamily: 'Fraunces_400Regular_Italic'` (expo-google-fonts paketinden).
`Plus Jakarta Sans`: UI default.
`IBM Plex Mono`: tabular rakamlar (sayaç, kod input).

Her `<Text>` componentine **explicit fontFamily** ver — RN'de default font platform'a göre değişir, tutarlılık için zorunlu.

### 4.4 — Animasyonlar

Prototipte CSS transition olan her yerde RN'de `react-native-reanimated` kullan:
- Buton press → `withSpring` scale 0.96
- Ekran geçişleri → Expo Router'ın default `slide_from_right` ama auth flow'da `fade`
- Karma token kazanılınca → `withSequence` ile pop + rotate

### 4.5 — Form validation

OTP, şifre strength, e-posta — hepsi `zod` şeması ile. Hata mesajları Türkçe, marka tonunda:
- ❌ "Geçersiz e-posta" → ✅ "E-posta adresinde bir terslik var gibi."
- ❌ "Şifre çok kısa" → ✅ "Biraz daha uzun olsun — en az 8 karakter."

---

## 5. Ekran listesi (öncelik sırası)

### Faz 1 — Iskele (önce bunlar)
1. `_layout.tsx` root + ThemeProvider + font loader
2. Theme tokens + useTheme hook
3. Paylaşılan UI primitive'leri: Button, Input, Badge, Tag, Card, KarmaToken
4. Bottom Tab layout

### Faz 2 — Auth flow (4 ekran)
`AuthLanding` → `AuthRegister` → `AuthOTP` → (login ayrı dal) `AuthLogin`
> Kaynak: `ds/Auth.jsx`

### Faz 3 — Onboarding (4 ekran)
`OnboardingWelcome` → `OnboardingValues` → `OnboardingLocation` → `OnboardingNotifications`
> Kaynak: `ds/Onboarding.jsx`

### Faz 4 — Ana akış (tabs)
`Home` → `Discover` → `Impact` → `Profile`
> Kaynak: `ds/Screens*.jsx`

### Faz 5 — Görev detayı & flow
`TaskDetail` → `Accept` → `EnRoute` → `Verify` → `Complete`
> Kaynak: `ds/TaskFlow.jsx`

Her fazın sonunda **commit** at, isim şeması: `feat(auth): register screen`, `feat(onboarding): values picker`.

---

## 6. Mock veri

`src/mocks/tasks.ts` dosyasını `ds/Screens*.jsx` içindeki sahte verilerden çıkart. En az 12 görev, kategorileri çeşitli:
- Kan bağışı (sağlık)
- Komşu yaşlıya market (mahalle)
- Park temizliği (çevre)
- Sokak hayvanı mama (hayvan)
- Kitap bağışı (eğitim)
- Gönüllü ders (eğitim)

Her task: `id, title, category, location, distance, duration, karmaReward, description, requirements[], imageUrl`.

---

## 7. Backend yok — şimdilik

Tüm API çağrıları **mock** olacak; `src/api/` altında her endpoint için bir async fn, 600-1200ms `setTimeout` gecikmeli mock response döndür. Gerçek backend entegre edildiğinde aynı imzayla gerçek fetch'e çevrilir.

---

## 8. Kalite kontrol

Teslimden önce:
- [ ] `npx expo start` temiz çalışıyor, warning yok.
- [ ] TypeScript `strict: true`, `any` yok.
- [ ] Tüm ekranlar iPhone SE (küçük) ve iPhone 15 Pro Max (büyük) viewport'ta düzgün.
- [ ] Dark mode tek tema (İyiBiri dark-first; light sonra gelecek).
- [ ] Ekran geçişlerinde jank yok, reanimated worklet'ler native thread'de.
- [ ] Accessibility: her button'da `accessibilityLabel`, her input'ta `accessibilityHint`.
- [ ] Metin Türkçe karakterler (ğĞıİşŞçÇöÖüÜ) her yerde düzgün render oluyor.

---

## 9. Soruların olursa

Eğer bir ekranda belirsizlik varsa (mesela: "Impact ekranında grafiği haftalık mı aylık mı göstereceğim?") **implementasyondan önce sor**, tahmin etme. Prototipe bakıp "şu ekranda X neden böyle?" diye sor — cevap gelmeden o ekrana başlama.

---

## 10. Teslim

Tamamlanınca README.md'ye şunları ekle:
- Kurulum (`pnpm install && npx expo start`)
- Klasör yapısı açıklaması
- Tasarım kararları ve handoff'tan sapmalar (varsa gerekçesiyle)
- Screenshot'lar (her ana ekrandan, iPhone 15 Pro viewport'ta)

Git log temiz, her commit tek konu.

---

**Başla.** İlk iş: handoff paketini oku ve Faz 1'i planla.
