# Handoff: İyiBiri — Mobil Gönüllülük & Bağış Uygulaması

## Genel Bakış

**İyiBiri**, Türkiye'deki gönüllüleri doğrulanmış STK'larla (TEMA, LÖSEV, Kızılay, AÇEV…) buluşturan mobil bir uygulamadır. Üç ana bağlama oturur:

1. **Görev akışı** — Kullanıcı keşfeder → başvurur → check-in yapar → tamamlar → **Karma** puanı kazanır.
2. **Bağış akışı** — Kampanyaya bağış yapar → miktar seçer → gözden geçirir → makbuz alır.
3. **STK üyeliği** — Aylık otomatik destek planı (ör. TEMA üyeliği) + her ay ekstra Karma.

Bu paket, ürünün **18 ekranlık hi-fi prototipini** içerir: onboarding, dashboard, keşfet, görev detayı + tüm görev state'leri, ödüller, profil, STK profili, üyelik, bağış, bildirim/seri/sıralama. Light/dark mode destekli.

---

## Tasarım Dosyaları Hakkında

Bu paketteki dosyalar **tasarım referansıdır — HTML + React (Babel runtime) ile oluşturulmuş prototiplerdir.** Görselleri, davranışları ve durumları göstermek için yazılmışlardır; **üretim kodu olarak doğrudan kopyalanmaları amaçlanmaz.**

Görev: Bu tasarımları **hedef kod tabanının mevcut ortamında yeniden oluşturmak** (React Native, Flutter, SwiftUI, native Android, vb.) — o projenin yerleşik pattern'leri ve kütüphaneleri kullanılarak. Eğer ortam henüz seçilmediyse, proje için en uygun framework seçilip tasarımlar orada uygulanmalı.

**Mobil uygulamadır** — tasarımlar 390×844 viewport'ta (iPhone 14 Pro) hazırlandı; 8px grid, 44px minimum tap hedefi.

---

## Fidelite

**Hi-Fi** (yüksek sadakat). Tüm renkler, tipografi, spacing, radius, shadow ve durumlar son değerlerle verilmiştir. Geliştirici bunları hedef kod tabanındaki mevcut component kütüphanesine birebir map'leyerek uygulamalıdır.

---

## Ekranlar

### Auth (4 adım) — onboarding'den önce

1. **AuthLanding** — Hoş geldin hub'ı; logo + slogan ("İyilik buradan başlar"), sosyal login (Apple, Google), e-posta ile kayıt CTA, "Zaten üye misin? Giriş yap" linki, KVKK + ToS micro-copy.
2. **AuthRegister** — E-posta kayıt formu: ad soyad, e-posta, şifre (göster/gizle toggle + strength meter), KVKK onay checkbox. İlerleme: 1/5 · Hesap adımı.
3. **AuthLogin** — E-posta + şifre girişi; "Beni hatırla" + "Şifremi unuttum" + sosyal login fallback (Apple/Google kompakt satır).
4. **AuthOTP** — 6 haneli kod doğrulama; büyük gold mail ikonu + 6 input kutusu (mono font, tabular), 00:42 geri sayım + "Tekrar gönder" + "Farklı e-posta kullan" linki.

### Onboarding (4 adım)

1. **OnboardingWelcome** — Logo + slogan ("İyi biri ol, iyi bir iz bırak"), başla CTA.
2. **OnboardingCauses** — Kullanıcı ilgi alanı seçer (Çevre, Eğitim, Sağlık, Hayvan, Afet, Yaşlı…). Min 3 seçim, chip-grid UI, seçili chip gold dolgulu.
3. **OnboardingLocation** — Konum izni (şehir kartı + harita önizleme), "Konumumu kullan" ve "Daha sonra" ikili buton.
4. **OnboardingReady** — Kişiselleştirilmiş özet ("7 yakın görev bulduk"), "Hadi başlayalım" CTA.

### Ana Akış

5. **Dashboard** — Üst: selamlama + karma rozeti. Orta: "Yakınındaki görevler" yatay carousel (3–4 kart). Alt: "Bu haftaki hedefin" ilerleme kartı, "Seri" (streak) mini modül, öne çıkan STK kartı. Alt nav bar (Ana, Keşfet, Karma, Profil).

6. **Discover** — Üst: search input + filtreler (kategori chip scroll). Altında **harita önizleme** (16:9, pin'ler). Sonra: "Yakınında bugün" görev listesi — kart: fotoğraf (thumb 88×88) + kategori chip + başlık + mesafe · saat · +karma değeri.

7. **MissionDetail** — Tam bleed foto (4:3), üstte back/share/heart. Foto altına başlık + kategori badge. Sonra: STK lockup (logo + isim + takip et). İlerleyen bölümler: Tarih/konum kartı, "Bu görevde ne yapacaksın" liste, gereksinimler, "Başvur" sticky CTA (+karma gösterir).

### Görev State'leri

8. **MissionApplied** — "Başvurun alındı" success state, ne zaman/nerede tekrarı, hatırlatma ayarı, takvim'e ekle butonu.
9. **MissionCheckIn** — Görev günü state; büyük QR/konum-doğrulama CTA, "Check-in yap" gold buton, geri sayım.
10. **MissionCompleted** — Tamamlandı state; "+150 Karma kazandın" celebratory kart, STK teşekkür mesajı, "Yorum bırak" + "Paylaş".

### Destek Ekranları

11. **Rewards (Karma)** — Karma bakiyesi büyük display, seviye çubuğu, "Kullanılabilir ödüller" grid (kafe indirimi, kitap vb.), "Kazanım geçmişi" liste.
12. **Profile** — Avatar + isim + şehir, istatistikler (toplam görev, saat, karma), rozet grid, geçmiş görevler.
13. **Notifications** — Bugün / Daha önce bölümleri; her kart: ikon + başlık + açıklama + timestamp. Swipe-to-clear.
14. **Streak** — 7 günlük seri heatmap, kilometre taşları (7, 30, 100 gün), motivasyon mesajı.
15. **Leaderboard** — Podyum top 3 (avatar + karma), "Sen #142" kendi satırı, altında sıralama listesi (haftalık/aylık/tüm zamanlar tab).

### STK + Üyelik

16. **NGOProfile** — Cover foto + logo lockup, stats (yıl, üye, fidan sayısı), hakkında, **üyelik teaser** (aylık destek CTA), aktif görev listesi, kampanya listesi.
17. **MembershipPlans** — 3 plan seçenek kartı (Destekçi ₺30/ay, Partner ₺75/ay, Şampiyon ₺150/ay). Her plan: Karma multiplier + özel rozet + erken erişim. Seçili plan gold border + "Üye ol" CTA.
18. **MembershipSuccess** — Confetti + "Hoş geldin, TEMA üyesi", rozet animasyonu, ilk ayın Karma bonusu badge.

### Bağış Akışı

19. **DonationCampaign** — Cover foto + urgency pill (ACİL · N gün kaldı), STK lockup, başlık, **ilerleme kartı** (toplanan/hedef + bağışçı sayısı), açıklama, etki kartları ("₺100 = 1 aileye 1 hafta ısınma"), "Bağış yap" sticky CTA.
20. **DonationAmount** — Miktar chip'leri (₺100 / ₺250 / ₺500 / ₺1000 / Diğer), sonuç: "Bu miktar şunu sağlar" etki gösterimi, anonim bağış toggle, devam CTA.
21. **DonationReview** — Özet: miktar + STK + kampanya, ödeme yöntemi seçici (kart/Apple Pay/Google Pay), KVKK onay checkbox, "Onayla" CTA.
22. **DonationThanks** — Büyük teşekkür + makbuz bilgisi ("E-postana gönderildi"), Karma kazanımı (₺1 = 1 Karma), "Paylaş" + "Başka kampanyalara göz at".

---

## Component Kütüphanesi

`ds/Components.jsx` içinde tanımlı, tüm ekranlarda kullanılan paylaşılan primitive'ler. Hedef kod tabanında bunların karşılıkları mevcutsa onları kullanın; yoksa aşağı notlara göre üretin.

| Component | Props | Kullanım |
|---|---|---|
| `Button` | `variant`: primary/secondary/ghost; `size`: sm/md/lg; `icon` | Tüm CTA'lar. Primary = gold bg + ink text. Secondary = ink800 bg + cream text + ink600 border. |
| `Chip` | `active`, `icon`, `onClick` | Filter chip. Active: gold soft bg + gold line border + gold text. |
| `Badge` | `variant`: default/onImage/success/warning/danger | Kategori etiketleri. `onImage`: backdrop-blur + yarı saydam. |
| `Card` | — | Temel kart: `ink800` bg, 1px `ink600` border, 16px radius, 16–20px padding. |
| `IconButton` | `icon`, `size=36` | 36×36 yuvarlak buton. Foto üstünde: ink900 %55 bg + cream icon. |
| `KarmaToken` | `value`, `size` | Karma rozeti — gold daire + sayı. `ds/KarmaToken.jsx`. |
| `Logo` | `size`, `mode` | İyiBiri logo. `ds/Logo.jsx`. |
| `NavBar` (mobile bottom) | `active` | 4 item: Ana / Keşfet / Karma / Profil. |

---

## Design Tokens

Tüm tokenlar `ds/tokens.js` içinde `window.IYI` altında export edilir. Uygulama bunları **semantic map** olarak okur — bu sayede light/dark mode tek bir toggle'la çalışır.

### Renk Sistemi

**Ham palet** (RAW):
```
INK SKALASI (dark mode ana yüzeyler)
#1A1612  ink          (deepest)
#24201B  ink900       app bg
#2E2923  ink800       card
#36302A  ink700       hover / raised
#3F3830  ink600       divider / border
#574E42  ink500
#7A6F5E  ink400       disabled
#A89E8A  ink300       muted text
#CEC5B2  ink200       secondary text
#E6DEC9  ink100
#F4EEDF  cream        primary text on dark

PAPER SKALASI (light mode ana yüzeyler)
#FAF5E9  paper        light app bg
#F5EEDD  paper100     light card
#EBE3CE  paper200     light hover
#D9CFB4  paper300     light divider
#B8AD92  paper400
#7A6F5E  paper500     light muted text
#3E3830  paper600     light secondary text
#241E18  paper700     light primary text

AKSAN
#E8C268  gold         (dark mode)
#B58F3D  goldDim      (light mode gold)
#C8553D  clay         aciliyet / terracotta aksan
#E9CFC2  blush        pastel aksan 1
#C4CBAC  sage         pastel aksan 2
#EADDB8  wheat        pastel aksan 3

STATUS
#6B8E4E  success
#D19B3C  warning
#B84E3B  danger
```

### Semantic Eşleşme

Ekranlar her zaman **semantic anahtarlar** üzerinden renk okur (`c.ink900`, `c.cream`, `c.gold` gibi). Light/dark mode switchine göre bu anahtarlar aşağıdakilere map'lenir:

| Key | Dark | Light | Kullanım |
|---|---|---|---|
| `ink900` | `#24201B` | `#FAF5E9` | App background |
| `ink800` | `#2E2923` | `#F5EEDD` | Card background |
| `ink700` | `#36302A` | `#EBE3CE` | Raised / hover |
| `ink600` | `#3F3830` | `#D9CFB4` | Divider / border |
| `ink300` | `#A89E8A` | `#7A6F5E` | Muted / secondary text |
| `cream` | `#F4EEDF` | `#241E18` | Primary text |
| `gold` | `#E8C268` | `#B58F3D` | Primary accent |
| `goldSoft` | `rgba(232,194,104,.12)` | `rgba(181,143,61,.14)` | Soft gold bg (chip, tag) |
| `goldLine` | `rgba(232,194,104,.32)` | `rgba(181,143,61,.42)` | Gold border |

**Önemli istisnalar** (mode'dan bağımsız):
- Foto hero üzerine yazılan başlıklar **her iki modda da** `#F4EEDF` (raw cream) + `text-shadow` kullanır — altta fotoğraf olduğu için mode map'ine tabi değildir.
- `clay`, `blush`, `sage`, `wheat`, `success`, `warning`, `danger` her iki modda da aynı raw değerlerdedir.

### Tipografi

```
Display    Fraunces               ui-serif, Georgia fallback
UI         Plus Jakarta Sans      -apple-system, BlinkMacSystemFont fallback
Mono       IBM Plex Mono          ui-monospace, SF Mono fallback
```

**Tip skalası** (`window.IYI.type`):
```
d1   display  56/1.02   w500  -0.03em    ekran başlığı (büyük)
d2   display  44/1.05   w500  -0.028em
d3   display  32/1.10   w500  -0.02em
h1   ui       24/1.20   w700  -0.02em    kart başlığı
h2   ui       20/1.25   w700  -0.02em
body ui       15/1.55   w400   0
small ui      13/1.5    w400   0
eyebrow ui    11/1      w700  .08em uppercase
```

**Font yüklemesi**: `App v2.html` üst kısmında Google Fonts link etiketi var — hedef projede kendi font pipeline'ınıza entegre edin (Fraunces 400/500, Jakarta Sans 400/500/600/700, IBM Plex Mono 400).

### Spacing

8px grid: **4, 8, 12, 16, 20, 24, 32, 40, 56, 72** px. Kart iç padding genelde 16–20, kart dış margin 16.

### Radius

```
sm    8px    chip iç, tag
md    12px   mini buton, input
lg    16px   kart (default)
xl    20px   büyük kart, modal
full  999px  chip, pill, avatar
```

### Shadow

```
card       0 4px 12px rgba(0,0,0,.18)      dark kart
cardLift   0 8px 24px rgba(0,0,0,.3)       raised (NGO logo)
gold       0 6px 14px rgba(232,194,104,.25) gold pill highlight
textOnImg  0 2px 16px rgba(0,0,0,.5)       foto üstü metin
```

---

## Etkileşim & Davranış

### Navigasyon Akışı

```
Onboarding (1→2→3→4) → Dashboard
Dashboard ↔ Discover ↔ MissionDetail → Apply → CheckIn → Completed → Dashboard
Dashboard → NGOProfile → MembershipPlans → MembershipSuccess → NGOProfile
NGOProfile / Discover → DonationCampaign → DonationAmount → DonationReview → DonationThanks
Alt nav: Dashboard / Discover / Rewards / Profile
```

### Animasyon

- **Ekran geçişleri**: 260ms cubic-bezier(.2,.8,.2,1) — iOS-benzeri slide-push.
- **Button press**: 120ms scale(0.97) ease-out.
- **Chip toggle**: 180ms bg + border transition.
- **Progress bar (kampanya/streak)**: 800ms ease-out width animation on mount.
- **Karma kazanımı**: +N değeri 600ms count-up + 400ms scale-bounce.
- **Confetti (MembershipSuccess)**: 2s one-shot.

### Durumlar

- **Hover**: dokunmatik olduğu için minimum — sadece desktop prototip için `ink700` bg.
- **Active/pressed**: scale(0.97), opacity(.92).
- **Disabled**: opacity .45, cursor disallowed, onClick no-op.
- **Loading**: skeleton kart — `ink700` bg, shimmer (1.4s linear).
- **Empty state**: merkezi ikon + "Henüz N yok" + CTA.
- **Error**: `danger` renginde toast, 3s auto-dismiss.

### Form Validasyonu

- Bağış miktarı: min ₺10, max ₺100.000, integer.
- KVKK checkbox: zorunlu (Review ekranında CTA disabled until checked).
- Onboarding causes: min 3 seçim (CTA disabled until).

### Responsive

Mobil-first, tek kolon. Tablet/desktop için iki kolonlu layout ileride — bu prototip mobile viewport'ta (390px) test edilmiştir.

---

## State Yönetimi

Gerekli state değişkenleri (global store — Redux/Zustand/Riverpod ne kullanıyorsanız):

```
user: { id, name, avatar, city, karma, level, streak, joinedAt }
missions: { [id]: { title, ngo, category, photo, date, location, karmaReward, state } }
  state: 'available' | 'applied' | 'checkin_ready' | 'completed'
ngos: { [id]: { name, logo, cover, stats, missions, campaigns, isMember } }
campaigns: { [id]: { title, ngo, raised, goal, donors, daysLeft, desc } }
donations: [ { campaignId, amount, date, receiptUrl } ]
memberships: [ { ngoId, plan, startedAt, monthlyAmount } ]
notifications: [ { id, type, title, body, timestamp, read } ]
ui: { mode: 'dark'|'light', onboardingDone: bool }
```

### Önemli Transition'lar

- `apply(missionId)` → görev state 'applied' + calendar reminder + notification kaydı.
- `checkIn(missionId)` → konum doğrula + state 'checkin_ready' → 'completed' (görev bitince).
- `complete(missionId)` → karma += reward, streak güncelle, profile.totalMissions++.
- `donate({ campaignId, amount })` → backend call + karma += amount (₺1 = 1 Karma) + receipt e-mail.
- `subscribeMembership({ ngoId, plan })` → backend recurring payment setup.

### Data Fetching

- Dashboard: yakındaki görevler — `GET /missions?near={lat},{lng}&limit=6`
- Discover: filtrelere göre — `GET /missions?category=X&city=Y&date=Z`
- NGOProfile: `GET /ngos/{id}` + `/ngos/{id}/missions` + `/ngos/{id}/campaigns`
- Donation: `POST /donations` (idempotency key ile).

---

## Assets

### Logolar (`assets/logos/`)

- `tema-logo.png` — TEMA Vakfı
- `losev-logo.png` — LÖSEV
- `kizilay-logo.png` — Türk Kızılay
- `acev-logo.png` — AÇEV
- (NGO logoları telif haklıdır — üretimde her STK ile kullanım anlaşması yapılmalı.)

### İkonlar (`ds/icons.jsx`)

Inline SVG olarak yazılmış custom icon set: `chevron, heart, share, pin, flame, clock, users, check, plus, info, star, calendar, expand`. Hedef projede mevcut ikon kütüphanesi (Feather, Phosphor, SF Symbols, Material Symbols) varsa oraya map'leyin.

### Görüntüler

Prototipte Unsplash URL'leri kullanıldı. Üretimde **kendi görüntü pipeline'ınızı** kurun — STK'lardan alınmış gerçek görev/kampanya fotoğrafları, CDN üzerinden servis edilmeli.

---

## Dosyalar

```
design_handoff_iyibiri/
├── App v2.html              # Tüm ekranları tek sayfada gösteren katalog (18 phone frame)
├── ds/
│   ├── tokens.js            # Renkler, tipografi, spacing, radius, shadow — semantic light/dark map
│   ├── icons.jsx            # Custom icon set
│   ├── Components.jsx       # Shared UI primitives (Button, Chip, Badge, Card, IconButton)
│   ├── Blocks.jsx           # Kompozit bloklar (StatCard, ProgressCard, FilterRow…)
│   ├── KarmaToken.jsx       # Karma rozeti
│   ├── Logo.jsx             # İyiBiri logo
│   ├── Screens.jsx          # Dashboard, Discover, MissionDetail, Rewards, Profile
│   ├── Screens2.jsx         # MissionApplied/CheckIn/Completed, Onboarding (1–4), Notifications, Streak, Leaderboard
│   └── Screens3.jsx         # NGOProfile, MembershipPlans/Success, Donation (Campaign/Amount/Review/Thanks)
└── assets/
    ├── logos/               # STK logoları (PNG)
    └── icons/               # Ekstra ikon dosyaları
```

### Nereden Başlamalı?

1. **`App v2.html`'i bir tarayıcıda aç** — tüm 18 ekranı bir arada canlı gör. Sağ üstte light/dark toggle var.
2. **`ds/tokens.js`'i oku** — tüm design value'ları buradan sabit olarak oku ya da hedef kod tabanındaki tema dosyasına port et.
3. **`ds/Components.jsx`'e bak** — Button/Chip/Badge/Card gibi primitive'lerin her varyantı burada. Hedef projenin mevcut component'leriyle 1:1 eşleştir.
4. **Ekran dosyaları** (`Screens.jsx`, `Screens2.jsx`, `Screens3.jsx`) — her fonksiyon bir ekrandır; layout, props, state örnekleri görünür.

---

## Notlar

- **Para birimi**: tüm rakamlar Türk Lirası (₺). Format: `₺1.250` (binlik nokta, ondalık yok). Bağış girişinde: `₺1.000,00` (ondalık 2 hane).
- **Dil**: TR. Copywriting tonu sıcak/samimi ama düşük yoğunluklu ("Hadi başlayalım", "Bugün bir iz bırak"). İngilizce versiyonu hazırlanacaksa localization anahtarları önceden çıkarılmalı.
- **Erişilebilirlik**: Tüm tap hedefleri ≥44×44. Karşıtlık oranları WCAG AA geçer (cream-on-ink900 = 12.8:1; gold-on-ink900 = 9.1:1). Light mode'da paper700-on-paper = 14.6:1.
- **Dark mode default** — ürün dark'ta başlar; kullanıcı light'a geçebilir. Tercih `localStorage`'a yazılır (üretimde `AsyncStorage` / secure prefs).
- **Karma ekonomisi**: 1 saat gönüllülük ≈ 50 karma; 1 TL bağış = 1 karma. Denge geliştirme aşamasında ayarlanacak.

---

## Sorular?

Bu handoff paketindeki tasarımlar soru/düzeltme ihtiyacı doğurursa, dosyaları açan geliştirici tasarımcıya geri dönebilir: her ekran, dark + light mod için test edildi; sticky CTA'lar phone frame içinde; foto üstü başlıklar `textShadow` ile okunabilir.
