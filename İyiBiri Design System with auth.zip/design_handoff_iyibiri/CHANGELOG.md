# Changelog

## v2.1 — Final polish (son revizyon)

**Düzeltmeler:**
- DonationCampaign sticky CTA artık light mode'da beyaz/paper, dark mode'da koyu/ink olarak render edilir (mode-aware bg).
- Discover harita: hardcoded `#2E2923`/`#24201B` değerleri `c.ink800`/`c.ink900` semantic anahtarlara çevrildi — light mode'da paper zemine geçer.
- Discover harita SVG path'leri (`#E8C268`, `#C4CBAC`) ve grid stroke'u (`#3F3830`) semantic tokenlara çevrildi.
- MissionDetail foto hero başlığı: `c.cream` → raw `#F4EEDF` + `textShadow`. Light mode'da dark bg-on-photo tutarsızlığı giderildi.
- JSX text içindeki `\'` kaçış karakterleri düzeltildi (parse hatası).

**Eklenenler:**
- `screens_index.json` — 22 ekranın programatik şeması (type shapes, navigation graph dahil).
- `examples/` — hedef framework'te örnek component implementasyonları.

## v2.0 — Full prototype

- 18 ekran hi-fi tamamlandı.
- Light/dark mode toggle.
- Full palette + tipografi + spacing + shadow + radius token sistemi.
- STK (NGO), üyelik, ve bağış akışları eklendi.
- Premium × Warm palet: ink skalası + paper skalası + gold + pastel aksanlar.

## v1.0 — Initial design exploration

- Yön A ve Yön B varyantları (`explore/DirA*`, `explore/DirB*`).
- Temel görev akışı (Dashboard, Discover, MissionDetail, Rewards, Profile).
