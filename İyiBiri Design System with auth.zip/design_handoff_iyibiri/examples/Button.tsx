// examples/Button.tsx
// React Native implementation of the İyiBiri Button component.
// Matches ds/Components.jsx — Button (variants: primary, secondary, ghost)
//
// Assumes: your project uses a theme provider exposing the same semantic
// keys as ds/tokens.js (ink900, cream, gold, goldDim, ink600, etc.).

import React from 'react';
import { Pressable, Text, ActivityIndicator, StyleSheet, View } from 'react-native';
import { useTheme } from './theme'; // your project's theme hook — replace path as needed

type Variant = 'primary' | 'secondary' | 'ghost';
type Size = 'sm' | 'md' | 'lg';

interface Props {
  label: string;
  onPress?: () => void;
  variant?: Variant;
  size?: Size;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  disabled?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
}

export function Button({
  label,
  onPress,
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'left',
  disabled,
  loading,
  fullWidth,
}: Props) {
  const c = useTheme().color;

  // Size scale — matches Components.jsx
  const sizing = {
    sm: { h: 36, px: 14, font: 13, gap: 6, radius: 10 },
    md: { h: 48, px: 18, font: 15, gap: 8, radius: 14 },
    lg: { h: 56, px: 22, font: 16, gap: 10, radius: 16 },
  }[size];

  // Variant tokens
  const styles = {
    primary: {
      bg: c.gold,
      fg: '#241E18', // ink-on-gold, stays dark regardless of mode
      border: 'transparent',
    },
    secondary: {
      bg: c.ink800,
      fg: c.cream,
      border: c.ink600,
    },
    ghost: {
      bg: 'transparent',
      fg: c.cream,
      border: 'transparent',
    },
  }[variant];

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => [
        {
          height: sizing.h,
          paddingHorizontal: sizing.px,
          borderRadius: sizing.radius,
          backgroundColor: styles.bg,
          borderWidth: 1,
          borderColor: styles.border,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: sizing.gap,
          opacity: disabled ? 0.45 : pressed ? 0.92 : 1,
          transform: [{ scale: pressed ? 0.97 : 1 }],
          alignSelf: fullWidth ? 'stretch' : 'flex-start',
        },
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={styles.fg} />
      ) : (
        <>
          {icon && iconPosition === 'left' && <View>{icon}</View>}
          <Text
            style={{
              fontFamily: 'PlusJakartaSans-Bold',
              fontSize: sizing.font,
              fontWeight: '700',
              letterSpacing: -0.02 * sizing.font,
              color: styles.fg,
            }}
          >
            {label}
          </Text>
          {icon && iconPosition === 'right' && <View>{icon}</View>}
        </>
      )}
    </Pressable>
  );
}
