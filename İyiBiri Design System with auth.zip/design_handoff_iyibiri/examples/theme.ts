// examples/theme.ts
// Reference theme for React Native / React — ports ds/tokens.js to a
// strongly-typed theme with light/dark variants.
//
// Usage:
//   import { ThemeProvider, useTheme } from './theme';
//   <ThemeProvider mode="dark"> <App/> </ThemeProvider>
//   const { color, font, spacing } = useTheme();

import React, { createContext, useContext, useMemo, useState } from 'react';

// ────────── RAW PALETTE ──────────
export const RAW = {
  ink: '#1A1612',
  ink900: '#24201B',
  ink800: '#2E2923',
  ink700: '#36302A',
  ink600: '#3F3830',
  ink500: '#574E42',
  ink400: '#7A6F5E',
  ink300: '#A89E8A',
  ink200: '#CEC5B2',
  ink100: '#E6DEC9',
  cream: '#F4EEDF',

  paper: '#FAF5E9',
  paper100: '#F5EEDD',
  paper200: '#EBE3CE',
  paper300: '#D9CFB4',
  paper400: '#B8AD92',
  paper500: '#7A6F5E',
  paper600: '#3E3830',
  paper700: '#241E18',

  gold: '#E8C268',
  goldDim: '#B58F3D',
  goldSoftD: 'rgba(232,194,104,0.12)',
  goldLineD: 'rgba(232,194,104,0.32)',
  goldSoftL: 'rgba(181,143,61,0.14)',
  goldLineL: 'rgba(181,143,61,0.42)',

  clay: '#C8553D',
  claySoft: 'rgba(200,85,61,0.12)',
  blush: '#E9CFC2',
  sage: '#C4CBAC',
  wheat: '#EADDB8',

  success: '#6B8E4E',
  warning: '#D19B3C',
  danger: '#B84E3B',
} as const;

// ────────── SEMANTIC MAP ──────────
type SemanticColors = {
  ink: string;
  ink900: string;
  ink800: string;
  ink700: string;
  ink600: string;
  ink500: string;
  ink400: string;
  ink300: string;
  ink200: string;
  ink100: string;
  cream: string;
  gold: string;
  goldDim: string;
  goldSoft: string;
  goldLine: string;
  clay: string;
  claySoft: string;
  blush: string;
  sage: string;
  wheat: string;
  success: string;
  warning: string;
  danger: string;
};

const DARK: SemanticColors = {
  ink: RAW.ink,
  ink900: RAW.ink900,
  ink800: RAW.ink800,
  ink700: RAW.ink700,
  ink600: RAW.ink600,
  ink500: RAW.ink500,
  ink400: RAW.ink400,
  ink300: RAW.ink300,
  ink200: RAW.ink200,
  ink100: RAW.ink100,
  cream: RAW.cream,
  gold: RAW.gold,
  goldDim: RAW.goldDim,
  goldSoft: RAW.goldSoftD,
  goldLine: RAW.goldLineD,
  clay: RAW.clay,
  claySoft: RAW.claySoft,
  blush: RAW.blush,
  sage: RAW.sage,
  wheat: RAW.wheat,
  success: RAW.success,
  warning: RAW.warning,
  danger: RAW.danger,
};

const LIGHT: SemanticColors = {
  ink: RAW.paper700,
  ink900: RAW.paper,
  ink800: RAW.paper100,
  ink700: RAW.paper200,
  ink600: RAW.paper300,
  ink500: RAW.paper400,
  ink400: RAW.paper400,
  ink300: RAW.paper500,
  ink200: RAW.paper600,
  ink100: RAW.paper700,
  cream: RAW.paper700,
  gold: RAW.goldDim,
  goldDim: RAW.goldDim,
  goldSoft: RAW.goldSoftL,
  goldLine: RAW.goldLineL,
  clay: RAW.clay,
  claySoft: RAW.claySoft,
  blush: RAW.blush,
  sage: RAW.sage,
  wheat: RAW.wheat,
  success: RAW.success,
  warning: RAW.warning,
  danger: RAW.danger,
};

// ────────── TYPOGRAPHY ──────────
export const font = {
  display: 'Fraunces',
  ui: 'PlusJakartaSans',
  mono: 'IBMPlexMono',
};

export const type = {
  d1: { family: 'display', size: 56, lineHeight: 1.02, weight: '500', letterSpacing: -0.03 },
  d2: { family: 'display', size: 44, lineHeight: 1.05, weight: '500', letterSpacing: -0.028 },
  d3: { family: 'display', size: 32, lineHeight: 1.1, weight: '500', letterSpacing: -0.02 },
  h1: { family: 'ui', size: 24, lineHeight: 1.2, weight: '700', letterSpacing: -0.02 },
  h2: { family: 'ui', size: 20, lineHeight: 1.25, weight: '700', letterSpacing: -0.02 },
  body: { family: 'ui', size: 15, lineHeight: 1.55, weight: '400', letterSpacing: 0 },
  small: { family: 'ui', size: 13, lineHeight: 1.5, weight: '400', letterSpacing: 0 },
  eyebrow: { family: 'ui', size: 11, lineHeight: 1, weight: '700', letterSpacing: 0.08 },
} as const;

// ────────── SPACING & RADIUS ──────────
export const spacing = { xs: 4, sm: 8, md: 12, base: 16, lg: 20, xl: 24, '2xl': 32, '3xl': 40, '4xl': 56, '5xl': 72 };
export const radius = { sm: 8, md: 12, lg: 16, xl: 20, full: 999 };

// ────────── CONTEXT ──────────
type Mode = 'dark' | 'light';

interface Theme {
  mode: Mode;
  color: SemanticColors;
  font: typeof font;
  type: typeof type;
  spacing: typeof spacing;
  radius: typeof radius;
  setMode: (m: Mode) => void;
}

const ThemeCtx = createContext<Theme | null>(null);

export function ThemeProvider({ children, initial = 'dark' as Mode }: { children: React.ReactNode; initial?: Mode }) {
  const [mode, setMode] = useState<Mode>(initial);
  const value = useMemo<Theme>(
    () => ({
      mode,
      color: mode === 'dark' ? DARK : LIGHT,
      font,
      type,
      spacing,
      radius,
      setMode,
    }),
    [mode],
  );
  return <ThemeCtx.Provider value={value}>{children}</ThemeCtx.Provider>;
}

export function useTheme(): Theme {
  const ctx = useContext(ThemeCtx);
  if (!ctx) throw new Error('useTheme must be used inside <ThemeProvider>');
  return ctx;
}
