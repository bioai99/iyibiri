# İyiBiri — Developer Implementation Guide

Adım adım hedef kod tabanına port kılavuzu.

## 1. Tema sistemi

`examples/theme.ts` dosyasını kopyala ve projenin kök sağlayıcısını sar:

```tsx
import { ThemeProvider } from './theme';

export default function App() {
  return (
    <ThemeProvider initial="dark">
      <Navigation/>
    </ThemeProvider>
  );
}
```

Her ekranda:
```tsx
const { color: c, font, spacing } = useTheme();
```

## 2. Font yükleme

```
Fraunces         400, 500     — display
Plus Jakarta Sans 400, 500, 600, 700 — UI
IBM Plex Mono    400          — mono (tabular rakamlar)
```

RN için: `react-native-asset` veya `expo-font`. Web için: `@fontsource/*` ya da Google Fonts `<link>`.

## 3. Component port sırası

Önce paylaşılan primitive'leri port et, sonra ekranları:

1. **Button** — `examples/Button.tsx` referans
2. **Chip** — filter toggle, active state gold soft bg + border
3. **Badge** — onImage varyantı kritik (backdrop-blur)
4. **Card** — temel konteyner (ink800 bg, ink600 border, radius:16)
5. **IconButton** — foto hero üstünde yuvarlak kontrol
6. **KarmaToken** — `ds/KarmaToken.jsx`'i referans alarak SVG veya vektör component
7. **Logo** — `ds/Logo.jsx`'den SVG/vektör
8. **NavBar (bottom)** — 4 tab: Ana/Keşfet/Karma/Profil
9. **Icon set** — `ds/icons.jsx`'deki 14 ikonu hedef ikon kütüphanesine map'le

Sonra ekranlar — `screens_index.json`'daki sırayla:
1. Onboarding 4 ekranı
2. Dashboard + Discover + MissionDetail
3. Mission state akışı (Applied → CheckIn → Completed)
4. Rewards + Profile
5. Notifications + Streak + Leaderboard
6. NGOProfile + Membership
7. Donation akışı

## 4. Navigasyon

React Navigation (RN) veya expo-router kullanıyorsan, `screens_index.json`'daki `navigationGraph` alanını stack yapısına dönüştür:

```tsx
const Stack = createNativeStackNavigator();
<Stack.Navigator screenOptions={{ headerShown: false }}>
  <Stack.Screen name="OnboardingWelcome" component={OnboardingWelcome}/>
  {/* ... */}
</Stack.Navigator>
```

Alt nav için `BottomTabNavigator`.

## 5. Animasyonlar

`react-native-reanimated` öner:
- Ekran geçişi: 260ms cubic-bezier(.2,.8,.2,1)
- Button press: `useAnimatedStyle` → scale(0.97), 120ms
- Progress bar: `withTiming(targetWidth, { duration: 800, easing: Easing.out(Easing.cubic) })`
- Karma count-up: `useSharedValue` + `withTiming(n, 600ms)`, `useDerivedValue` ile render

## 6. Harita

Discover ekranındaki harita prototipte SVG placeholder — üretimde:
- **react-native-maps** (Google Maps / Apple Maps)
- Custom marker: prototipteki pin pill'i port et (gold bg + karma sayısı + 2px kuyruk)
- Cluster için `@teovilla/react-native-web-maps` veya backend-side clustering

## 7. Data layer

`screens_index.json`'daki `typeShapes` alanı backend API'den beklenen şekli gösterir. Tavsiye:
- **TanStack Query** (React Query) — data fetching + cache
- **Zustand** veya **Redux Toolkit** — UI state (current user, mode tercihi, vs.)
- Offline-first değilse SWR de yeterli

## 8. Validasyon

Form validasyonu için **zod** + **react-hook-form**:
```ts
const donationSchema = z.object({
  amount: z.number().int().min(10).max(100000),
  kvkk: z.literal(true),
});
```

## 9. Erişilebilirlik

- Tüm tap hedefleri ≥44×44 (Button component'inde `minHeight:44` ayarlı)
- `accessibilityLabel` her interaktif element için
- `accessibilityRole` button/link/image olarak ayarla
- Dinamik yazı tipi boyutu: RN'de `allowFontScaling`, max 1.3x
- Karşıtlık oranları WCAG AA geçer — zaten token sisteminden geliyor

## 10. Localization

Tüm stringler TR. İngilizce planı varsa:
- **i18next** veya RN için **react-i18next** / **Lingui**
- String extraction için `screens_index.json`'a bakıp her ekranın kopyasını TR + EN anahtarlarına dönüştür

---

## Çalıştırma

Prototipi görmek için:
```
open "App v2.html"
```
veya
```
python3 -m http.server 8000
# sonra: http://localhost:8000/App%20v2.html
```

Sağ üstteki light/dark toggle ile mode değişimini test et.
