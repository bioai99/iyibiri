// ════════════════════════════════════════════════════════════════════════
// İyiBiri — Auth Screens (Landing / Register / Login / OTP)
// ════════════════════════════════════════════════════════════════════════
// Design language matches Screens2.jsx Onboarding set:
//  - Fraunces display + italic gold accent
//  - Jakarta Sans body
//  - ink900 bg (dark) / paper bg (light) via semantic tokens
//  - progress dots: full set is [Auth → Onboarding1 → 2 → 3 → 4]
//  - Social login buttons use ink800 bg + ink600 border for contrast
//  - Form inputs use ds/Components.jsx InputField

(function () {
  const _C  = () => window.IYI.color;
  const _ff = () => window.IYI.font;

  // Social provider icons — inline SVG (minimal, recognisable)
  const ProviderIcons = {
    apple: (p={}) => (
      <svg width={p.size||18} height={p.size||18} viewBox="0 0 24 24" fill="currentColor">
        <path d="M17.05 20.28c-.98.95-2.05.86-3.08.4-1.09-.47-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09M12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25"/>
      </svg>
    ),
    google: (p={}) => (
      <svg width={p.size||18} height={p.size||18} viewBox="0 0 24 24">
        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
      </svg>
    ),
    mail: (p={}) => (
      <svg width={p.size||18} height={p.size||18} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="5" width="18" height="14" rx="2"/>
        <path d="m3 7 9 6 9-6"/>
      </svg>
    ),
  };

  // Shared progress dots — 5 steps total (Auth → Cause → Location → Ready + landing)
  // Auth screens are conceptually step 0 — before onboarding.
  // Reuse the same pill style as onboarding for continuity.
  const AuthDots = ({ active=0, total=5 }) => {
    const c = _C();
    return (
      <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
        {Array.from({length:total}).map((_,i)=>(
          <div key={i} style={{
            width: i===active ? 18 : 6, height:3, borderRadius:999,
            background: i<=active ? c.gold : c.ink600,
            transition:'width .2s ease'
          }}/>
        ))}
      </div>
    );
  };

  // ─────────────────────────────────────────────────────────────
  // AUTH LANDING — Hoş geldin ekranı
  // Sosyal login + e-posta ile devam + "Zaten üye misin?"
  // ─────────────────────────────────────────────────────────────
  function AuthLanding() {
    const c = _C();
    return (
      <div style={{background:c.ink900,minHeight:'100%',display:'flex',flexDirection:'column',height:'844px'}}>
        {/* Hero visual — Fraunces wordmark'ı olan karma token'la sadelestirilmis */}
        <div style={{flex:'1 1 auto',position:'relative',overflow:'hidden',minHeight:320}}>
          <div style={{position:'absolute',inset:0,background:`radial-gradient(ellipse at 50% 30%, rgba(232,194,104,.22), transparent 65%), radial-gradient(ellipse at 20% 90%, rgba(233,207,194,.1), transparent 55%), ${c.ink900}`}}/>
          {/* Logo cluster */}
          <div style={{position:'absolute',top:'32%',left:'50%',transform:'translate(-50%,-50%)',display:'flex',flexDirection:'column',alignItems:'center',gap:18}}>
            <KarmaToken size={92}/>
            <div style={{fontFamily:_ff().display,fontSize:34,fontWeight:500,letterSpacing:'-0.028em',color:c.cream}}>
              İyi<span style={{fontStyle:'italic',color:c.gold}}>Biri</span>
            </div>
          </div>
          {/* subtle decorative tokens */}
          <div style={{position:'absolute',top:'16%',left:'14%',opacity:.35}}><KarmaToken size={22}/></div>
          <div style={{position:'absolute',top:'20%',right:'16%',opacity:.28}}><KarmaToken size={18}/></div>
          <div style={{position:'absolute',bottom:'12%',right:'18%',opacity:.3}}><KarmaToken size={26}/></div>
        </div>

        {/* Copy + auth actions */}
        <div style={{padding:'24px 28px 44px'}}>
          <h1 style={{margin:0,fontFamily:_ff().display,fontSize:30,fontWeight:400,letterSpacing:'-0.03em',lineHeight:1.1,color:c.cream,textAlign:'center'}}>
            <span style={{fontStyle:'italic',color:c.gold}}>İyilik</span> buradan başlar.
          </h1>
          <p style={{margin:'10px 0 0',fontFamily:_ff().ui,fontSize:14,lineHeight:1.55,color:c.ink200,textAlign:'center'}}>
            Hesabını aç, Türkiye'nin en büyük gönüllülük topluluğuna katıl.
          </p>

          {/* Social providers — secondary button styling */}
          <div style={{marginTop:28,display:'flex',flexDirection:'column',gap:10}}>
            <button style={{
              width:'100%',height:52,borderRadius:14,background:c.ink800,border:`1px solid ${c.ink600}`,
              color:c.cream,fontFamily:_ff().ui,fontSize:15,fontWeight:600,cursor:'pointer',
              display:'flex',alignItems:'center',justifyContent:'center',gap:10,
            }}>
              <ProviderIcons.apple size={18}/> Apple ile devam et
            </button>
            <button style={{
              width:'100%',height:52,borderRadius:14,background:c.ink800,border:`1px solid ${c.ink600}`,
              color:c.cream,fontFamily:_ff().ui,fontSize:15,fontWeight:600,cursor:'pointer',
              display:'flex',alignItems:'center',justifyContent:'center',gap:10,
            }}>
              <ProviderIcons.google size={18}/> Google ile devam et
            </button>
          </div>

          {/* Divider */}
          <div style={{display:'flex',alignItems:'center',gap:10,margin:'20px 0 14px'}}>
            <div style={{flex:1,height:1,background:c.ink600}}/>
            <span style={{fontFamily:_ff().ui,fontSize:11,color:c.ink400,letterSpacing:'.08em',textTransform:'uppercase'}}>veya</span>
            <div style={{flex:1,height:1,background:c.ink600}}/>
          </div>

          {/* Email CTA — primary */}
          <button style={{
            width:'100%',height:52,borderRadius:14,background:c.gold,border:'none',color:'#241E18',
            fontFamily:_ff().ui,fontSize:15,fontWeight:700,cursor:'pointer',
            display:'flex',alignItems:'center',justifyContent:'center',gap:10,
            boxShadow:'0 1px 2px rgba(26,22,18,.3), inset 0 1px 0 rgba(255,255,255,.3)',
          }}>
            <ProviderIcons.mail size={16}/> E-posta ile kayıt ol
          </button>

          {/* Sign-in link */}
          <p style={{margin:'18px 0 0',fontFamily:_ff().ui,fontSize:13,color:c.ink300,textAlign:'center'}}>
            Zaten üye misin? <span style={{color:c.gold,fontWeight:600,cursor:'pointer'}}>Giriş yap</span>
          </p>

          {/* Legal micro-copy */}
          <p style={{margin:'14px 0 0',fontFamily:_ff().ui,fontSize:10.5,color:c.ink400,textAlign:'center',lineHeight:1.5}}>
            Devam ederek <span style={{textDecoration:'underline'}}>Kullanım Koşulları</span>'nı ve <span style={{textDecoration:'underline'}}>Gizlilik Politikası</span>'nı kabul etmiş olursun.
          </p>
        </div>
      </div>
    );
  }

  // ─────────────────────────────────────────────────────────────
  // AUTH REGISTER — E-posta ile kayıt
  // ─────────────────────────────────────────────────────────────
  function AuthRegister() {
    const c = _C();
    const [form, setForm] = React.useState({
      name: 'Ayşe Kara',
      email: 'ayse@example.com',
      password: '••••••••••',
    });
    const [kvkk, setKvkk] = React.useState(true);
    const [showPw, setShowPw] = React.useState(false);

    const Input = ({ label, value, onChange, type='text', rightSlot }) => (
      <div>
        <div style={{fontFamily:_ff().ui,fontSize:11,fontWeight:600,color:c.ink300,letterSpacing:'.06em',textTransform:'uppercase',marginBottom:6}}>{label}</div>
        <div style={{position:'relative',background:c.ink800,border:`1px solid ${c.ink600}`,borderRadius:12,display:'flex',alignItems:'center'}}>
          <input value={value} onChange={e=>onChange(e.target.value)} type={type}
            style={{flex:1,background:'transparent',border:'none',outline:'none',padding:'14px 14px',fontFamily:_ff().ui,fontSize:15,color:c.cream,fontWeight:500}}
          />
          {rightSlot && <div style={{paddingRight:12}}>{rightSlot}</div>}
        </div>
      </div>
    );

    return (
      <div style={{background:c.ink900,minHeight:'100%',height:'844px',display:'flex',flexDirection:'column'}}>
        {/* Header */}
        <div style={{padding:'58px 20px 0',display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:36,height:36,borderRadius:'50%',background:c.ink800,border:`1px solid ${c.ink600}`,display:'flex',alignItems:'center',justifyContent:'center',color:c.cream,cursor:'pointer'}}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m15 18-6-6 6-6"/></svg>
          </div>
          <div style={{flex:1,textAlign:'center',fontFamily:_ff().ui,fontSize:13,fontWeight:600,color:c.ink200}}>1 / 5 · Hesap</div>
          <div style={{width:36}}/>
        </div>

        {/* Title */}
        <div style={{padding:'28px 24px 0'}}>
          <h1 style={{margin:0,fontFamily:_ff().display,fontSize:28,fontWeight:400,letterSpacing:'-0.028em',lineHeight:1.1,color:c.cream}}>
            <span style={{fontStyle:'italic',color:c.gold}}>Tanışalım</span> —<br/>birkaç bilgi yeter.
          </h1>
          <p style={{margin:'8px 0 0',fontFamily:_ff().ui,fontSize:13,color:c.ink300,lineHeight:1.55}}>
            Hesabını oluşturduğunda, Karma bakiyen ve aldığın rozetler seninle kalır.
          </p>
        </div>

        {/* Form */}
        <div style={{padding:'24px 24px 0',display:'flex',flexDirection:'column',gap:14,flex:1}}>
          <Input label="Ad soyad" value={form.name} onChange={v=>setForm({...form,name:v})}/>
          <Input label="E-posta" value={form.email} onChange={v=>setForm({...form,email:v})} type="email"/>
          <Input label="Şifre" value={form.password} onChange={v=>setForm({...form,password:v})} type={showPw?'text':'password'}
            rightSlot={
              <button onClick={()=>setShowPw(s=>!s)} style={{background:'transparent',border:'none',color:c.ink300,cursor:'pointer',fontFamily:_ff().ui,fontSize:11,fontWeight:600,letterSpacing:'.06em',textTransform:'uppercase'}}>
                {showPw?'Gizle':'Göster'}
              </button>
            }
          />
          {/* Password strength hint */}
          <div style={{display:'flex',gap:4,marginTop:-6}}>
            <div style={{flex:1,height:3,borderRadius:999,background:c.gold}}/>
            <div style={{flex:1,height:3,borderRadius:999,background:c.gold}}/>
            <div style={{flex:1,height:3,borderRadius:999,background:c.goldDim,opacity:.6}}/>
            <div style={{flex:1,height:3,borderRadius:999,background:c.ink600}}/>
          </div>
          <div style={{fontFamily:_ff().ui,fontSize:11,color:c.ink400,marginTop:-8}}>
            En az 8 karakter, 1 rakam. Güçlü şifre.
          </div>

          {/* KVKK checkbox */}
          <label style={{display:'flex',alignItems:'flex-start',gap:10,marginTop:4,cursor:'pointer'}}>
            <div onClick={()=>setKvkk(k=>!k)} style={{
              width:22,height:22,borderRadius:7,marginTop:1,
              background:kvkk?c.gold:'transparent',
              border:`1.5px solid ${kvkk?c.gold:c.ink500}`,
              display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,
            }}>
              {kvkk && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#241E18" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>}
            </div>
            <span style={{fontFamily:_ff().ui,fontSize:12,color:c.ink200,lineHeight:1.5}}>
              <span style={{color:c.cream,fontWeight:600}}>KVKK Aydınlatma Metni</span>'ni okudum, kabul ediyorum. E-posta ile ara sıra ilham verici görevler almayı kabul ediyorum.
            </span>
          </label>
        </div>

        {/* Footer */}
        <div style={{padding:'18px 24px 28px'}}>
          <button disabled={!kvkk} style={{
            width:'100%',height:52,borderRadius:14,
            background:kvkk?c.gold:c.ink700,border:'none',
            color:kvkk?'#241E18':c.ink400,
            fontFamily:_ff().ui,fontSize:15,fontWeight:700,cursor:kvkk?'pointer':'not-allowed',
            display:'flex',alignItems:'center',justifyContent:'center',gap:8,
            boxShadow:kvkk?'0 1px 2px rgba(26,22,18,.3), inset 0 1px 0 rgba(255,255,255,.3)':'none',
          }}>
            Hesabımı oluştur →
          </button>
          <div style={{marginTop:16}}><AuthDots active={0}/></div>
        </div>
      </div>
    );
  }

  // ─────────────────────────────────────────────────────────────
  // AUTH LOGIN — E-posta + şifre ile giriş
  // ─────────────────────────────────────────────────────────────
  function AuthLogin() {
    const c = _C();
    const [email, setEmail] = React.useState('ayse@example.com');
    const [pw, setPw] = React.useState('••••••••');
    const [showPw, setShowPw] = React.useState(false);
    const [remember, setRemember] = React.useState(true);

    return (
      <div style={{background:c.ink900,minHeight:'100%',height:'844px',display:'flex',flexDirection:'column'}}>
        {/* Header */}
        <div style={{padding:'58px 20px 0',display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:36,height:36,borderRadius:'50%',background:c.ink800,border:`1px solid ${c.ink600}`,display:'flex',alignItems:'center',justifyContent:'center',color:c.cream,cursor:'pointer'}}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m15 18-6-6 6-6"/></svg>
          </div>
          <div style={{flex:1}}/>
        </div>

        {/* Brand mark */}
        <div style={{padding:'16px 24px 0',display:'flex',alignItems:'center',gap:12}}>
          <KarmaToken size={44}/>
          <div style={{fontFamily:_ff().display,fontSize:22,fontWeight:500,letterSpacing:'-0.025em',color:c.cream}}>
            İyi<span style={{fontStyle:'italic',color:c.gold}}>Biri</span>
          </div>
        </div>

        {/* Title */}
        <div style={{padding:'32px 24px 0'}}>
          <h1 style={{margin:0,fontFamily:_ff().display,fontSize:30,fontWeight:400,letterSpacing:'-0.03em',lineHeight:1.1,color:c.cream}}>
            <span style={{fontStyle:'italic',color:c.gold}}>Tekrar</span><br/>hoş geldin.
          </h1>
          <p style={{margin:'10px 0 0',fontFamily:_ff().ui,fontSize:14,color:c.ink300,lineHeight:1.55}}>
            Devam eden 2 görevin var. Seri'ni bugün bozma.
          </p>
        </div>

        {/* Form */}
        <div style={{padding:'28px 24px 0',display:'flex',flexDirection:'column',gap:14,flex:1}}>
          <div>
            <div style={{fontFamily:_ff().ui,fontSize:11,fontWeight:600,color:c.ink300,letterSpacing:'.06em',textTransform:'uppercase',marginBottom:6}}>E-posta</div>
            <div style={{background:c.ink800,border:`1px solid ${c.ink600}`,borderRadius:12}}>
              <input value={email} onChange={e=>setEmail(e.target.value)} type="email"
                style={{width:'100%',background:'transparent',border:'none',outline:'none',padding:'14px',fontFamily:_ff().ui,fontSize:15,color:c.cream,fontWeight:500,boxSizing:'border-box'}}
              />
            </div>
          </div>
          <div>
            <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
              <span style={{fontFamily:_ff().ui,fontSize:11,fontWeight:600,color:c.ink300,letterSpacing:'.06em',textTransform:'uppercase'}}>Şifre</span>
              <span style={{fontFamily:_ff().ui,fontSize:11,fontWeight:600,color:c.gold,cursor:'pointer'}}>Şifremi unuttum</span>
            </div>
            <div style={{position:'relative',background:c.ink800,border:`1px solid ${c.ink600}`,borderRadius:12,display:'flex',alignItems:'center'}}>
              <input value={pw} onChange={e=>setPw(e.target.value)} type={showPw?'text':'password'}
                style={{flex:1,background:'transparent',border:'none',outline:'none',padding:'14px',fontFamily:_ff().ui,fontSize:15,color:c.cream,fontWeight:500}}
              />
              <button onClick={()=>setShowPw(s=>!s)} style={{background:'transparent',border:'none',color:c.ink300,cursor:'pointer',padding:'0 12px',fontFamily:_ff().ui,fontSize:11,fontWeight:600,letterSpacing:'.06em',textTransform:'uppercase'}}>
                {showPw?'Gizle':'Göster'}
              </button>
            </div>
          </div>

          {/* Remember me */}
          <label style={{display:'flex',alignItems:'center',gap:10,cursor:'pointer'}}>
            <div onClick={()=>setRemember(r=>!r)} style={{
              width:20,height:20,borderRadius:6,
              background:remember?c.gold:'transparent',
              border:`1.5px solid ${remember?c.gold:c.ink500}`,
              display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,
            }}>
              {remember && <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#241E18" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>}
            </div>
            <span style={{fontFamily:_ff().ui,fontSize:13,color:c.ink200}}>Beni hatırla</span>
          </label>
        </div>

        {/* Footer */}
        <div style={{padding:'18px 24px 28px'}}>
          <button style={{
            width:'100%',height:52,borderRadius:14,background:c.gold,border:'none',color:'#241E18',
            fontFamily:_ff().ui,fontSize:15,fontWeight:700,cursor:'pointer',
            display:'flex',alignItems:'center',justifyContent:'center',gap:8,
            boxShadow:'0 1px 2px rgba(26,22,18,.3), inset 0 1px 0 rgba(255,255,255,.3)',
          }}>
            Giriş yap →
          </button>

          {/* Divider */}
          <div style={{display:'flex',alignItems:'center',gap:10,margin:'18px 0 12px'}}>
            <div style={{flex:1,height:1,background:c.ink600}}/>
            <span style={{fontFamily:_ff().ui,fontSize:11,color:c.ink400,letterSpacing:'.08em',textTransform:'uppercase'}}>veya</span>
            <div style={{flex:1,height:1,background:c.ink600}}/>
          </div>

          {/* Social fallback — compact row */}
          <div style={{display:'flex',gap:10}}>
            <button style={{flex:1,height:48,borderRadius:12,background:c.ink800,border:`1px solid ${c.ink600}`,color:c.cream,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:8,fontFamily:_ff().ui,fontSize:13,fontWeight:600}}>
              <ProviderIcons.apple size={16}/> Apple
            </button>
            <button style={{flex:1,height:48,borderRadius:12,background:c.ink800,border:`1px solid ${c.ink600}`,color:c.cream,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:8,fontFamily:_ff().ui,fontSize:13,fontWeight:600}}>
              <ProviderIcons.google size={16}/> Google
            </button>
          </div>

          <p style={{margin:'16px 0 0',fontFamily:_ff().ui,fontSize:13,color:c.ink300,textAlign:'center'}}>
            Hesabın yok mu? <span style={{color:c.gold,fontWeight:600,cursor:'pointer'}}>Kayıt ol</span>
          </p>
        </div>
      </div>
    );
  }

  // ─────────────────────────────────────────────────────────────
  // AUTH OTP — SMS / e-posta kod doğrulama (6 hane)
  // ─────────────────────────────────────────────────────────────
  function AuthOTP() {
    const c = _C();
    const [digits, setDigits] = React.useState(['4','7','2','9','',''] );
    const filled = digits.filter(Boolean).length;

    return (
      <div style={{background:c.ink900,minHeight:'100%',height:'844px',display:'flex',flexDirection:'column'}}>
        {/* Header */}
        <div style={{padding:'58px 20px 0',display:'flex',alignItems:'center',gap:10}}>
          <div style={{width:36,height:36,borderRadius:'50%',background:c.ink800,border:`1px solid ${c.ink600}`,display:'flex',alignItems:'center',justifyContent:'center',color:c.cream,cursor:'pointer'}}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="m15 18-6-6 6-6"/></svg>
          </div>
          <div style={{flex:1,textAlign:'center',fontFamily:_ff().ui,fontSize:13,fontWeight:600,color:c.ink200}}>Doğrulama</div>
          <div style={{width:36}}/>
        </div>

        {/* Icon */}
        <div style={{padding:'40px 24px 0',display:'flex',justifyContent:'center'}}>
          <div style={{
            width:88,height:88,borderRadius:'50%',
            background:`radial-gradient(circle at 30% 30%, ${c.gold}, ${c.goldDim})`,
            display:'flex',alignItems:'center',justifyContent:'center',
            boxShadow:'0 10px 30px rgba(232,194,104,.25), inset 0 1px 0 rgba(255,255,255,.3)',
          }}>
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#3E2F14" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="5" width="18" height="14" rx="2"/>
              <path d="m3 7 9 6 9-6"/>
            </svg>
          </div>
        </div>

        {/* Title */}
        <div style={{padding:'22px 28px 0',textAlign:'center'}}>
          <h1 style={{margin:0,fontFamily:_ff().display,fontSize:26,fontWeight:400,letterSpacing:'-0.025em',lineHeight:1.15,color:c.cream}}>
            E-postana <span style={{fontStyle:'italic',color:c.gold}}>kod gönderdik</span>
          </h1>
          <p style={{margin:'10px 0 0',fontFamily:_ff().ui,fontSize:13,color:c.ink300,lineHeight:1.55}}>
            <span style={{color:c.cream,fontWeight:600}}>ayse@example.com</span> adresine gelen 6 haneli kodu gir.
          </p>
        </div>

        {/* OTP inputs */}
        <div style={{padding:'36px 20px 0',display:'flex',justifyContent:'center',gap:8}}>
          {digits.map((d,i)=>(
            <div key={i} style={{
              width:46,height:58,borderRadius:12,
              background:d?c.ink800:c.ink900,
              border:`1.5px solid ${d?c.gold:i===filled?c.goldLine:c.ink600}`,
              display:'flex',alignItems:'center',justifyContent:'center',
              fontFamily:_ff().mono,fontSize:24,fontWeight:700,color:c.cream,
              letterSpacing:'-0.02em',
              boxShadow:i===filled&&!d?`0 0 0 4px ${c.goldSoft}`:'none',
              transition:'all .15s ease',
            }}>
              {d || (i===filled ? <div style={{width:2,height:22,background:c.gold,animation:'blink 1s step-start infinite'}}/> : '')}
            </div>
          ))}
        </div>
        <style>{`@keyframes blink { 50% { opacity:0; } }`}</style>

        {/* Resend */}
        <div style={{padding:'28px 24px 0',textAlign:'center'}}>
          <div style={{fontFamily:_ff().ui,fontSize:13,color:c.ink300}}>
            Kod gelmedi mi? <span style={{color:c.ink400}}>00:42</span>
          </div>
          <button style={{marginTop:10,background:'transparent',border:'none',color:c.gold,fontFamily:_ff().ui,fontSize:13,fontWeight:600,cursor:'pointer'}}>
            Tekrar gönder
          </button>
        </div>

        <div style={{flex:1}}/>

        {/* Footer */}
        <div style={{padding:'18px 24px 28px'}}>
          <button disabled={filled<6} style={{
            width:'100%',height:52,borderRadius:14,
            background:filled===6?c.gold:c.ink700,border:'none',
            color:filled===6?'#241E18':c.ink400,
            fontFamily:_ff().ui,fontSize:15,fontWeight:700,cursor:filled===6?'pointer':'not-allowed',
            display:'flex',alignItems:'center',justifyContent:'center',gap:8,
            boxShadow:filled===6?'0 1px 2px rgba(26,22,18,.3), inset 0 1px 0 rgba(255,255,255,.3)':'none',
          }}>
            Doğrula →
          </button>
          <p style={{margin:'14px 0 0',fontFamily:_ff().ui,fontSize:11,color:c.ink400,textAlign:'center',lineHeight:1.5}}>
            Farklı bir <span style={{color:c.gold,fontWeight:600,cursor:'pointer'}}>e-posta</span> kullanmak ister misin?
          </p>
        </div>
      </div>
    );
  }

  Object.assign(window, { AuthLanding, AuthRegister, AuthLogin, AuthOTP });
})();
