// İyiBiri — Design System Tokens v2
// Palette: "Premium × Warm" — mürekkep zemin, mat altın aksan, terracotta bağlam.
// Light/dark mode semantic palette — sayfalar `window.IYI.color` üzerinden okur,
// `IYI.setMode('light' | 'dark')` ile toggle; `iyi:mode` event'i dispatch edilir.

(function () {
  // ────────── RAW PALETTE (ham değerler) ──────────
  const RAW = {
    ink:      '#1A1612',
    ink900:   '#24201B',
    ink800:   '#2E2923',
    ink700:   '#36302A',
    ink600:   '#3F3830',
    ink500:   '#574E42',
    ink400:   '#7A6F5E',
    ink300:   '#A89E8A',
    ink200:   '#CEC5B2',
    ink100:   '#E6DEC9',
    cream:    '#F4EEDF',

    paper:    '#FAF5E9',
    paper100: '#F5EEDD',
    paper200: '#EBE3CE',
    paper300: '#D9CFB4',
    paper400: '#B8AD92',
    paper500: '#7A6F5E',
    paper600: '#3E3830',
    paper700: '#241E18',

    gold:     '#E8C268',
    goldDim:  '#B58F3D',
    goldSoftD:'rgba(232,194,104,.12)',
    goldLineD:'rgba(232,194,104,.32)',
    goldSoftL:'rgba(181,143,61,.14)',
    goldLineL:'rgba(181,143,61,.42)',

    clay:     '#C8553D',
    claySoft: 'rgba(200,85,61,.12)',

    blush:    '#E9CFC2',
    sage:     '#C4CBAC',
    wheat:    '#EADDB8',

    success:  '#6B8E4E',
    warning:  '#D19B3C',
    danger:   '#B84E3B',
  };

  // ────────── DARK MODE SEMANTIC MAP ──────────
  // Eski kodun kullandığı bütün anahtarları (ink900, ink800, cream, vs.)
  // dark mode'da aynı renklere map'liyoruz. Light mode'da anlamlı ters eşleştirme.
  const DARK = {
    // Yüzeyler
    ink:      RAW.ink,
    ink900:   RAW.ink900,   // app bg
    ink800:   RAW.ink800,   // card
    ink700:   RAW.ink700,   // hover
    ink600:   RAW.ink600,   // divider
    ink500:   RAW.ink500,
    ink400:   RAW.ink400,
    ink300:   RAW.ink300,   // muted text
    ink200:   RAW.ink200,
    ink100:   RAW.ink100,
    cream:    RAW.cream,    // primary text

    paper:    RAW.paper,    // (ham değerler light-mode kart kullanımı için; normalde dark'ta kullanılmaz)
    paper100: RAW.paper100,
    paper200: RAW.paper200,
    paper300: RAW.paper300,
    paper400: RAW.paper400,
    paper500: RAW.paper500,
    paper600: RAW.paper600,
    paper700: RAW.paper700,

    gold:     RAW.gold,
    goldDim:  RAW.goldDim,
    goldSoft: RAW.goldSoftD,
    goldLine: RAW.goldLineD,

    clay:     RAW.clay,
    claySoft: RAW.claySoft,
    blush:    RAW.blush,
    sage:     RAW.sage,
    wheat:    RAW.wheat,

    success:  RAW.success,
    warning:  RAW.warning,
    danger:   RAW.danger,
  };

  // ────────── LIGHT MODE SEMANTIC MAP ──────────
  // Aynı anahtarları light için map'liyoruz. "ink900" light'ta "paper" olur;
  // "cream" light'ta "paper700" (primary text) olur; vb.
  // Böylece ekranlardaki hiçbir kodu değiştirmeden light/dark geçişi çalışır.
  const LIGHT = {
    // Yüzeyler — dark'taki ink skalasının light karşılığı
    ink:      RAW.paper700,
    ink900:   RAW.paper,      // app bg
    ink800:   RAW.paper100,   // card
    ink700:   RAW.paper200,   // hover / raised
    ink600:   RAW.paper300,   // divider
    ink500:   RAW.paper400,
    ink400:   RAW.paper400,
    ink300:   RAW.paper500,   // muted text — secondary
    ink200:   RAW.paper600,
    ink100:   RAW.paper700,
    cream:    RAW.paper700,   // primary text

    paper:    RAW.paper,
    paper100: RAW.paper100,
    paper200: RAW.paper200,
    paper300: RAW.paper300,
    paper400: RAW.paper400,
    paper500: RAW.paper500,
    paper600: RAW.paper600,
    paper700: RAW.paper700,

    gold:     RAW.goldDim,    // light mode'da daha koyu altın (kontrast için)
    goldDim:  RAW.goldDim,
    goldSoft: RAW.goldSoftL,
    goldLine: RAW.goldLineL,

    clay:     RAW.clay,
    claySoft: RAW.claySoft,
    blush:    RAW.blush,
    sage:     RAW.sage,
    wheat:    RAW.wheat,

    success:  RAW.success,
    warning:  RAW.warning,
    danger:   RAW.danger,
  };

  window.IYI = {
    mode: 'dark',
    setMode(m) {
      if (m !== 'dark' && m !== 'light') return;
      this.mode = m;
      this._applyMode();
      window.dispatchEvent(new CustomEvent('iyi:mode', { detail: m }));
    },
    _applyMode() {
      // color'ı mevcut moda göre refresh et
      const src = this.mode === 'light' ? LIGHT : DARK;
      Object.keys(src).forEach(k => { this.color[k] = src[k]; });
    },

    color: { ...DARK },  // ilk değer
    _raw: RAW,

    /* ────── TYPE ────── */
    font: {
      display: '"Fraunces", ui-serif, Georgia, serif',
      ui: '"Plus Jakarta Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',
      mono: '"IBM Plex Mono", ui-monospace, "SF Mono", Menlo, monospace',
    },

    type: {
      d1: { family:'display', size:56, lh:1.02, weight:500, track:'-0.03em' },
      d2: { family:'display', size:44, lh:1.05, weight:500, track:'-0.028em' },
      d3: { family:'display', size:32, lh:1.1,  weight:500, track:'-0.02em' },
      h1: { family:'ui', size:24, lh:1.2,  weight:700, track:'-0.02em' },
      h2: { family:'ui', size:20, lh:1.25, weight:700, track:'-0.02em' },
      h3: { family:'ui', size:17, lh:1.3,  weight:600, track:'-0.01em' },
      bodyLg: { family:'ui', size:16, lh:1.5, weight:400, track:'-0.01em' },
      body:   { family:'ui', size:14, lh:1.55, weight:400, track:'0' },
      bodySm: { family:'ui', size:13, lh:1.5,  weight:400, track:'0' },
      label:    { family:'ui', size:11, lh:1.3, weight:600, track:'.04em' },
      eyebrow:  { family:'ui', size:10, lh:1.2, weight:700, track:'.22em', upper:true },
      caption:  { family:'ui', size:11, lh:1.4, weight:500, track:'0' },
      numHero:  { family:'ui', size:56, lh:0.95, weight:700, track:'-0.035em', tabular:true },
      numBig:   { family:'ui', size:32, lh:1,    weight:700, track:'-0.025em', tabular:true },
      numMed:   { family:'ui', size:18, lh:1.1,  weight:700, track:'-0.015em', tabular:true },
    },

    radius: { xs:6, sm:10, md:12, lg:16, xl:20, pill:9999 },
    space:  { '0':0, '1':4, '2':8, '3':12, '4':16, '5':20, '6':24, '7':32, '8':40, '9':48, '10':64 },

    shadow: {
      sm:   '0 1px 2px rgba(26,22,18,.06), 0 2px 6px rgba(26,22,18,.04)',
      md:   '0 2px 4px rgba(26,22,18,.06), 0 8px 20px rgba(26,22,18,.06)',
      lg:   '0 4px 8px rgba(26,22,18,.08), 0 16px 36px rgba(26,22,18,.08)',
      xl:   '0 8px 16px rgba(26,22,18,.08), 0 32px 56px rgba(26,22,18,.08)',
      gold: '0 0 0 1px rgba(232,194,104,.3), 0 8px 24px rgba(232,194,104,.18)',
    },

    motion: {
      fast:   '160ms cubic-bezier(.2,.8,.2,1)',
      base:   '220ms cubic-bezier(.2,.8,.2,1)',
      slow:   '320ms cubic-bezier(.2,.8,.2,1)',
      spring: '360ms cubic-bezier(.34,1.56,.64,1)',
    },
  };

  window.IYI.typo = (k) => {
    const t = window.IYI.type[k];
    if (!t) return {};
    return {
      fontFamily: window.IYI.font[t.family],
      fontSize: t.size,
      lineHeight: t.lh,
      fontWeight: t.weight,
      letterSpacing: t.track,
      ...(t.upper ? { textTransform: 'uppercase' } : {}),
      ...(t.tabular ? { fontVariantNumeric: 'tabular-nums' } : {}),
    };
  };
})();
